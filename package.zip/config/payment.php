<?php

return [
    'zarinpal_api_key'=>'123456789zxcvbnmrtylkjhgfdsaqwertyui'
];
