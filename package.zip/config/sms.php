<?php
return [
    'username'=>'9392919229',
    'password'=>'37c89e52-0307-4ebd-b674-1d86869dee4f',
    'otp_from'=>'50004001919229'
];
